__version__ = '0.10.0'
git_version = '4da1de36247aa06622088e78508e0e38a4392e38'
